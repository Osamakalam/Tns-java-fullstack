package com.tnsif.placement.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
